<?php

namespace Drupal\facets\Exception;

/**
 * Represents an exception that occurred in some part of the Facets.
 */
class Exception extends \Exception {}
